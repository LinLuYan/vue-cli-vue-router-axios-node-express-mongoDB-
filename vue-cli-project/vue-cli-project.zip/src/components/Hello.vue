<template>
    <div>这是Hello</div>
</template>

<script>

export default {
    name: 'home',
    data () {
        return {
      
       }
    },
    created:function(){  
    }
}
</script>

<style scoped>

</style>