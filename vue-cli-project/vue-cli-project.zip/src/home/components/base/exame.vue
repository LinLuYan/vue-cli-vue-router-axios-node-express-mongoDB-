<template>
    <div class="exame">
        <div>
            <center class="title">{{params}}</center>
        </div>
        <div class="content"></div>
    </div>    
</template>

<script>
export default {
    name: 'exame',
    props:['params'],
    data () {
        return {
        }
    },
    created:function(){  
    },
    methods:{
    }
}
</script>

<style lang='scss' scoped>
.exame{
    .title{
        font-size:16px;
        padding-top:8px;
    }
    .content{
        
    }
}
</style>