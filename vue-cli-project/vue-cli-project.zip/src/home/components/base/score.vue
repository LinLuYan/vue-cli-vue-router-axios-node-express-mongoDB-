<template>
    <div>
    666
    </div>    
</template>

<script>
export default {
    name: 'score',
    data () {
        return {
        }
    },
    created:function(){  
    },
    methods:{
    }
}
</script>

<style lang='scss' scoped>

</style>