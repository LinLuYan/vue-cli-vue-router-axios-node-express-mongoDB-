<template>
    <div class="home">
        <router-view></router-view>
    </div>
</template>

<script>

export default {
    name: 'home',
    components: {
        
    }
}
</script>

<style scoped>

</style>