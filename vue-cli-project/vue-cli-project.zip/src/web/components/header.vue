<template>
    <div>66666666666666666
    </div>    
</template>

<script>

export default {
    name: 'home',
    data () {
        return {
            radio: '1'
        }
    },
    created:function(){  
    }
}
</script>

<style scoped>

</style>